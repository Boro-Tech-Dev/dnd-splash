
  # DD Marketing

  This is a code bundle for DD Marketing. The original project is available at https://www.figma.com/design/AWdP9k5QTTcWLTMhaWT10v/DD-Marketing.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  